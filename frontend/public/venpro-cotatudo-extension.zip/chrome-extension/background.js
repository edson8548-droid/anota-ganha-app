// Background service worker — gets Firebase token from Venpro

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getToken') {
    getTokenFromVenpro()
      .then(token => sendResponse({ token }))
      .catch(() => sendResponse({ token: null }));
    return true;
  }
});

async function getTokenFromVenpro() {
  // Try venpro.com.br tabs
  let tabs = await chrome.tabs.query({ url: 'https://venpro.com.br/*' });
  if (tabs.length === 0) {
    tabs = await chrome.tabs.query({ url: 'https://anota-ganha-app.web.app/*' });
  }
  if (tabs.length === 0) {
    tabs = await chrome.tabs.query({ url: 'https://anota-ganha-app.firebaseapp.com/*' });
  }
  if (tabs.length === 0) return null;

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        // Token saved by Venpro app via onIdTokenChanged
        return localStorage.getItem('venpro_ext_token');
      }
    });
    return results?.[0]?.result || null;
  } catch (err) {
    console.error('Error reading token:', err);
    return null;
  }
}
